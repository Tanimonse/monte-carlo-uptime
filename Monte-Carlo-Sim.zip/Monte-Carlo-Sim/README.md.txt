# Monte Carlo Simulation for Downtime Analysis

This repository contains a Python implementation of a Monte Carlo simulation to evaluate system uptime for the Virtual Oyster Card project. The simulation assesses the probability of achieving 99% uptime based on subsystem failure rates.

## Features
- Simulates daily subsystem failures over a defined period.
- Calculates overall system uptime.
- Provides statistical analysis and visualizations of results.

## Prerequisites
- Python 3.7 or later
- Required libraries are listed in `requirements.txt`.

## Installation
1. Clone this repository:
